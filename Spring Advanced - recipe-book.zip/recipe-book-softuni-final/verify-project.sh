#!/usr/bin/env bash
set -euo pipefail

mvn clean verify
mvn -f meal-plan-service/pom.xml clean verify

printf '\nMain JaCoCo report: %s\n' "$(pwd)/target/site/jacoco/index.html"
printf 'Microservice JaCoCo report: %s\n' "$(pwd)/meal-plan-service/target/site/jacoco/index.html"
