package bg.softuni.recipebook.service;

import bg.softuni.recipebook.dto.RecipeRequest;
import bg.softuni.recipebook.exception.BusinessRuleException;
import bg.softuni.recipebook.exception.ForbiddenActionException;
import bg.softuni.recipebook.exception.NotFoundException;
import bg.softuni.recipebook.model.entity.Category;
import bg.softuni.recipebook.model.entity.Recipe;
import bg.softuni.recipebook.model.entity.User;
import bg.softuni.recipebook.repository.RecipeRepository;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import java.lang.reflect.Field;
import java.util.Optional;
import java.util.UUID;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.mockito.Mockito.never;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

@ExtendWith(MockitoExtension.class)
class RecipeServiceTest {
    @Mock
    private RecipeRepository recipeRepository;
    @Mock
    private CategoryService categoryService;
    @Mock
    private UserService userService;
    @Mock
    private CurrentUser currentUser;

    private RecipeService recipeService;
    private User owner;
    private Category category;

    @BeforeEach
    void setUp() throws Exception {
        recipeService = new RecipeService(recipeRepository, categoryService, userService, currentUser);
        owner = new User();
        setId(owner, UUID.randomUUID());
        category = new Category();
        setId(category, UUID.randomUUID());
    }

    @Test
    void createPersistsMappedRecipe() {
        RecipeRequest request = request("Tomato soup");
        when(recipeRepository.findByTitleIgnoreCase("Tomato soup")).thenReturn(Optional.empty());
        when(categoryService.findById(request.getCategoryId())).thenReturn(category);
        when(userService.getCurrentUserEntity()).thenReturn(owner);
        when(recipeRepository.save(org.mockito.ArgumentMatchers.any(Recipe.class)))
                .thenAnswer(invocation -> invocation.getArgument(0));

        Recipe created = recipeService.create(request);

        assertEquals("Tomato soup", created.getTitle());
        assertEquals(owner, created.getAuthor());
        assertEquals(category, created.getCategory());
        verify(recipeRepository).save(created);
    }

    @Test
    void createRejectsDuplicateTitle() {
        Recipe existing = new Recipe();
        when(recipeRepository.findByTitleIgnoreCase("Tomato soup")).thenReturn(Optional.of(existing));

        assertThrows(BusinessRuleException.class, () -> recipeService.create(request("Tomato soup")));
        verify(recipeRepository, never()).save(org.mockito.ArgumentMatchers.any());
    }

    @Test
    void updateRejectsUserWhoIsNotOwnerOrAdmin() throws Exception {
        UUID recipeId = UUID.randomUUID();
        User anotherUser = new User();
        setId(anotherUser, UUID.randomUUID());
        Recipe recipe = new Recipe();
        recipe.setAuthor(owner);
        when(recipeRepository.findById(recipeId)).thenReturn(Optional.of(recipe));
        when(userService.getCurrentUserEntity()).thenReturn(anotherUser);
        when(currentUser.isAdmin()).thenReturn(false);

        assertThrows(ForbiddenActionException.class,
                () -> recipeService.update(recipeId, request("Updated soup")));
    }

    @Test
    void findByIdRejectsMissingRecipe() {
        UUID id = UUID.randomUUID();
        when(recipeRepository.findById(id)).thenReturn(Optional.empty());

        assertThrows(NotFoundException.class, () -> recipeService.findById(id));
    }

    private RecipeRequest request(String title) {
        RecipeRequest request = new RecipeRequest();
        request.setTitle(title);
        request.setIngredients("Tomatoes, water and herbs");
        request.setInstructions("Cook all ingredients together for twenty minutes.");
        request.setCookingMinutes(20);
        request.setImageUrl("");
        request.setCategoryId(UUID.randomUUID());
        return request;
    }

    private void setId(Object entity, UUID id) throws Exception {
        Field field = entity.getClass().getDeclaredField("id");
        field.setAccessible(true);
        field.set(entity, id);
    }
}
