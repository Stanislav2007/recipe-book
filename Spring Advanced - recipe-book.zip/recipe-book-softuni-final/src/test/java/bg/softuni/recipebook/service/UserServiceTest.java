package bg.softuni.recipebook.service;

import bg.softuni.recipebook.dto.RegisterRequest;
import bg.softuni.recipebook.exception.BusinessRuleException;
import bg.softuni.recipebook.model.entity.User;
import bg.softuni.recipebook.model.enums.UserRole;
import bg.softuni.recipebook.repository.UserRepository;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.security.crypto.password.PasswordEncoder;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

@ExtendWith(MockitoExtension.class)
class UserServiceTest {
    @Mock
    private UserRepository userRepository;
    @Mock
    private PasswordEncoder passwordEncoder;
    @Mock
    private CurrentUser currentUser;

    private UserService userService;

    @BeforeEach
    void setUp() {
        userService = new UserService(userRepository, passwordEncoder, currentUser);
    }

    @Test
    void registerHashesPasswordAndCreatesUserRole() {
        RegisterRequest request = request();
        when(passwordEncoder.encode("secret12")).thenReturn("hashed-password");

        userService.register(request);

        verify(userRepository).save(org.mockito.ArgumentMatchers.argThat(user ->
                user.getRole() == UserRole.USER && "hashed-password".equals(user.getPassword())));
    }

    @Test
    void registerRejectsDifferentPasswords() {
        RegisterRequest request = request();
        request.setConfirmPassword("different");

        assertThrows(BusinessRuleException.class, () -> userService.register(request));
    }

    @Test
    void currentUserMustBeAuthenticated() {
        when(currentUser.isLoggedIn()).thenReturn(false);

        assertThrows(BusinessRuleException.class, userService::getCurrentUserEntity);
    }

    private RegisterRequest request() {
        RegisterRequest request = new RegisterRequest();
        request.setUsername("newuser");
        request.setEmail("newuser@example.com");
        request.setPassword("secret12");
        request.setConfirmPassword("secret12");
        return request;
    }
}
