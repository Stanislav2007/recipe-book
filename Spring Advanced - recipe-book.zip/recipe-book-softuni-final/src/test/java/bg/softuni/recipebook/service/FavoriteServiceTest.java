package bg.softuni.recipebook.service;

import bg.softuni.recipebook.exception.BusinessRuleException;
import bg.softuni.recipebook.model.entity.Favorite;
import bg.softuni.recipebook.model.entity.Recipe;
import bg.softuni.recipebook.model.entity.User;
import bg.softuni.recipebook.repository.FavoriteRepository;
import org.junit.jupiter.api.Test;

import java.util.Optional;
import java.util.UUID;

import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.mockito.Mockito.*;

class FavoriteServiceTest {
    private final FavoriteRepository repository = mock(FavoriteRepository.class);
    private final UserService userService = mock(UserService.class);
    private final RecipeService recipeService = mock(RecipeService.class);
    private final FavoriteService service = new FavoriteService(repository, userService, recipeService);

    @Test
    void addCreatesFavorite() {
        UUID recipeId = UUID.randomUUID();
        User user = new User(); Recipe recipe = new Recipe();
        when(userService.getCurrentUserEntity()).thenReturn(user);
        when(recipeService.findById(recipeId)).thenReturn(recipe);
        service.add(recipeId);
        verify(repository).save(any(Favorite.class));
    }

    @Test
    void addRejectsDuplicate() {
        UUID recipeId = UUID.randomUUID();
        User user = new User(); Recipe recipe = new Recipe();
        when(userService.getCurrentUserEntity()).thenReturn(user);
        when(recipeService.findById(recipeId)).thenReturn(recipe);
        when(repository.existsByUserAndRecipe(user, recipe)).thenReturn(true);
        assertThrows(BusinessRuleException.class, () -> service.add(recipeId));
    }

    @Test
    void removeDeletesExistingFavorite() {
        UUID recipeId = UUID.randomUUID();
        User user = new User(); Recipe recipe = new Recipe(); Favorite favorite = new Favorite();
        when(userService.getCurrentUserEntity()).thenReturn(user);
        when(recipeService.findById(recipeId)).thenReturn(recipe);
        when(repository.findByUserAndRecipe(user, recipe)).thenReturn(Optional.of(favorite));
        service.remove(recipeId);
        verify(repository).delete(favorite);
    }
}
