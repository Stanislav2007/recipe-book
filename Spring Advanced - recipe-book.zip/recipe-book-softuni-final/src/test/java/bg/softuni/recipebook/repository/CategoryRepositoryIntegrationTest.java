package bg.softuni.recipebook.repository;

import bg.softuni.recipebook.model.entity.Category;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.orm.jpa.DataJpaTest;

import static org.junit.jupiter.api.Assertions.assertTrue;

@DataJpaTest
class CategoryRepositoryIntegrationTest {
    @Autowired private CategoryRepository repository;

    @Test
    void findsCategoryByName() {
        Category category = new Category();
        category.setName("Test category");
        category.setDescription("Integration test category");
        repository.save(category);
        assertTrue(repository.findByName("Test category").isPresent());
    }
}
