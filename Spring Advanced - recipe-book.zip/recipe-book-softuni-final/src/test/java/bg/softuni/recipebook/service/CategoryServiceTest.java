package bg.softuni.recipebook.service;

import bg.softuni.recipebook.dto.CategoryRequest;
import bg.softuni.recipebook.exception.BusinessRuleException;
import bg.softuni.recipebook.exception.NotFoundException;
import bg.softuni.recipebook.model.entity.Category;
import bg.softuni.recipebook.repository.CategoryRepository;
import org.junit.jupiter.api.Test;

import java.util.Optional;
import java.util.UUID;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

class CategoryServiceTest {
    private final CategoryRepository repository = mock(CategoryRepository.class);
    private final CategoryService service = new CategoryService(repository);

    @Test
    void createSavesCategory() {
        CategoryRequest request = new CategoryRequest();
        request.setName("Soups");
        request.setDescription("Warm homemade soups");
        when(repository.findByName("Soups")).thenReturn(Optional.empty());
        service.create(request);
        verify(repository).save(argThat(c -> c.getName().equals("Soups")));
    }

    @Test
    void createRejectsDuplicate() {
        CategoryRequest request = new CategoryRequest();
        request.setName("Soups");
        request.setDescription("Warm homemade soups");
        when(repository.findByName("Soups")).thenReturn(Optional.of(new Category()));
        assertThrows(BusinessRuleException.class, () -> service.create(request));
    }

    @Test
    void findByIdRejectsMissingCategory() {
        UUID id = UUID.randomUUID();
        when(repository.findById(id)).thenReturn(Optional.empty());
        assertThrows(NotFoundException.class, () -> service.findById(id));
    }
}
