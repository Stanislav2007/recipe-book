package bg.softuni.recipebook.service;

import bg.softuni.recipebook.client.MealPlanClient;
import bg.softuni.recipebook.model.entity.Recipe;
import bg.softuni.recipebook.model.entity.User;
import bg.softuni.recipebook.exception.BusinessRuleException;
import org.junit.jupiter.api.Test;

import java.time.LocalDate;
import java.util.UUID;

import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.mockito.ArgumentMatchers.argThat;
import static org.mockito.Mockito.*;

class MealPlanServiceTest {
    @Test
    void scheduleInvokesFeignClient() {
        MealPlanClient client = mock(MealPlanClient.class);
        UserService userService = mock(UserService.class);
        RecipeService recipeService = mock(RecipeService.class);
        MealPlanService service = new MealPlanService(client, userService, recipeService);
        UUID recipeId = UUID.randomUUID();
        Recipe recipe = new Recipe(); recipe.setTitle("Soup");
        User user = mock(User.class); when(user.getId()).thenReturn(UUID.randomUUID());
        when(recipeService.findById(recipeId)).thenReturn(recipe);
        when(userService.getCurrentUserEntity()).thenReturn(user);
        service.schedule(recipeId, LocalDate.now().plusDays(1), "Dinner");
        verify(client).create(any());
    }
    @Test
    void scheduleNormalizesMealTypeBeforeFeignCall() {
        MealPlanClient client = mock(MealPlanClient.class);
        UserService userService = mock(UserService.class);
        RecipeService recipeService = mock(RecipeService.class);
        MealPlanService service = new MealPlanService(client, userService, recipeService);
        UUID recipeId = UUID.randomUUID();
        Recipe recipe = new Recipe();
        recipe.setTitle("Soup");
        User user = mock(User.class);
        when(user.getId()).thenReturn(UUID.randomUUID());
        when(recipeService.findById(recipeId)).thenReturn(recipe);
        when(userService.getCurrentUserEntity()).thenReturn(user);

        service.schedule(recipeId, LocalDate.now().plusDays(1), " dinner ");

        verify(client).create(argThat(request -> "Dinner".equals(request.mealType())));
    }

    @Test
    void scheduleRejectsPastDateBeforeCallingDependencies() {
        MealPlanClient client = mock(MealPlanClient.class);
        UserService userService = mock(UserService.class);
        RecipeService recipeService = mock(RecipeService.class);
        MealPlanService service = new MealPlanService(client, userService, recipeService);

        assertThrows(BusinessRuleException.class,
                () -> service.schedule(UUID.randomUUID(), LocalDate.now().minusDays(1), "Dinner"));

        verifyNoInteractions(client, userService, recipeService);
    }

    @Test
    void scheduleRejectsUnsupportedMealType() {
        MealPlanClient client = mock(MealPlanClient.class);
        UserService userService = mock(UserService.class);
        RecipeService recipeService = mock(RecipeService.class);
        MealPlanService service = new MealPlanService(client, userService, recipeService);

        assertThrows(BusinessRuleException.class,
                () -> service.schedule(UUID.randomUUID(), LocalDate.now().plusDays(1), "Midnight"));

        verifyNoInteractions(client, userService, recipeService);
    }

}
