package bg.softuni.mealplan.dto;

import java.time.LocalDate;
import java.util.UUID;

public record MealPlanResponse(UUID id, UUID userId, UUID recipeId, String recipeTitle,
                               LocalDate plannedDate, String mealType, boolean completed) {
}
