package bg.softuni.mealplan.repository;

import bg.softuni.mealplan.entity.MealPlan;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;
import java.util.UUID;

public interface MealPlanRepository extends JpaRepository<MealPlan, UUID> {
    List<MealPlan> findAllByUserIdOrderByPlannedDateAsc(UUID userId);
    boolean existsByUserIdAndRecipeIdAndPlannedDateAndMealType(UUID userId, UUID recipeId, java.time.LocalDate plannedDate, String mealType);
}
