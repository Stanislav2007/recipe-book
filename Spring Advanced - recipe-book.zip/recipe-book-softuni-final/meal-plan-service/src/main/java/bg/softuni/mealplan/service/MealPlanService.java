package bg.softuni.mealplan.service;

import bg.softuni.mealplan.dto.MealPlanRequest;
import bg.softuni.mealplan.dto.MealPlanResponse;
import bg.softuni.mealplan.entity.MealPlan;
import bg.softuni.mealplan.exception.DuplicateMealPlanException;
import bg.softuni.mealplan.exception.MealPlanNotFoundException;
import bg.softuni.mealplan.repository.MealPlanRepository;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;
import java.util.Locale;
import java.util.UUID;

@Service
public class MealPlanService {
    private static final Logger LOGGER = LoggerFactory.getLogger(MealPlanService.class);
    private final MealPlanRepository repository;

    public MealPlanService(MealPlanRepository repository) { this.repository = repository; }

    public List<MealPlanResponse> findByUser(UUID userId) {
        return repository.findAllByUserIdOrderByPlannedDateAsc(userId).stream().map(this::map).toList();
    }

    @Transactional
    public MealPlanResponse create(MealPlanRequest request) {
        if (repository.existsByUserIdAndRecipeIdAndPlannedDateAndMealType(request.userId(), request.recipeId(), request.plannedDate(), normalizeMealType(request.mealType()))) {
            throw new DuplicateMealPlanException("This recipe is already planned for the selected meal.");
        }
        MealPlan plan = new MealPlan();
        plan.setUserId(request.userId()); plan.setRecipeId(request.recipeId()); plan.setRecipeTitle(request.recipeTitle());
        plan.setPlannedDate(request.plannedDate());
        plan.setMealType(normalizeMealType(request.mealType()));
        MealPlan saved = repository.save(plan);
        LOGGER.info("Created meal plan {} for user {}", saved.getId(), saved.getUserId());
        return map(saved);
    }

    @Transactional
    public MealPlanResponse complete(UUID id, UUID userId) {
        MealPlan plan = ownedPlan(id, userId);
        plan.setCompleted(true);
        LOGGER.info("Completed meal plan {}", id);
        return map(repository.save(plan));
    }

    @Transactional
    public void delete(UUID id, UUID userId) {
        repository.delete(ownedPlan(id, userId));
        LOGGER.info("Deleted meal plan {}", id);
    }

    private MealPlan ownedPlan(UUID id, UUID userId) {
        MealPlan plan = repository.findById(id).orElseThrow(() -> new MealPlanNotFoundException("Meal plan not found."));
        if (!plan.getUserId().equals(userId)) throw new MealPlanNotFoundException("Meal plan not found for this user.");
        return plan;
    }

    private String normalizeMealType(String mealType) {
        String normalized = mealType.trim().toLowerCase(Locale.ROOT);
        return Character.toUpperCase(normalized.charAt(0)) + normalized.substring(1);
    }

    private MealPlanResponse map(MealPlan p) {
        return new MealPlanResponse(p.getId(), p.getUserId(), p.getRecipeId(), p.getRecipeTitle(), p.getPlannedDate(), p.getMealType(), p.isCompleted());
    }
}
