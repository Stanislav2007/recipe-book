package bg.softuni.mealplan.dto;

import jakarta.validation.constraints.FutureOrPresent;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Pattern;
import jakarta.validation.constraints.Size;

import java.time.LocalDate;
import java.util.UUID;

public record MealPlanRequest(@NotNull UUID userId, @NotNull UUID recipeId,
                              @NotBlank @Size(max = 120) String recipeTitle,
                              @NotNull @FutureOrPresent LocalDate plannedDate,
                              @NotBlank @Size(max = 30) @Pattern(regexp = "(?i)Breakfast|Lunch|Dinner|Snack", message = "Meal type must be Breakfast, Lunch, Dinner, or Snack") String mealType) {
}
