package bg.softuni.mealplan.exception;

public class MealPlanNotFoundException extends RuntimeException {
    public MealPlanNotFoundException(String message) { super(message); }
}
