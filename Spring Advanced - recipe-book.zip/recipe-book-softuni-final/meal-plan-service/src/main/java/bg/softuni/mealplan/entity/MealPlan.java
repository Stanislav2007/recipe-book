package bg.softuni.mealplan.entity;

import jakarta.persistence.*;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.FutureOrPresent;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Pattern;
import jakarta.validation.constraints.Size;

import java.time.LocalDate;
import java.util.UUID;

@Entity
@Table(name = "meal_plans")
public class MealPlan {
    @Id
    @GeneratedValue(strategy = GenerationType.UUID)
    private UUID id;
    @NotNull @Column(nullable = false)
    private UUID userId;
    @NotNull @Column(nullable = false)
    private UUID recipeId;
    @NotBlank @Size(max = 120) @Column(nullable = false, length = 120)
    private String recipeTitle;
    @NotNull
    @FutureOrPresent
    @Column(nullable = false)
    private LocalDate plannedDate;
    @NotBlank
    @Size(max = 30)
    @Pattern(regexp = "Breakfast|Lunch|Dinner|Snack")
    @Column(nullable = false, length = 30)
    private String mealType;
    @Column(nullable = false)
    private boolean completed;

    public UUID getId() { return id; }
    public UUID getUserId() { return userId; }
    public void setUserId(UUID userId) { this.userId = userId; }
    public UUID getRecipeId() { return recipeId; }
    public void setRecipeId(UUID recipeId) { this.recipeId = recipeId; }
    public String getRecipeTitle() { return recipeTitle; }
    public void setRecipeTitle(String recipeTitle) { this.recipeTitle = recipeTitle; }
    public LocalDate getPlannedDate() { return plannedDate; }
    public void setPlannedDate(LocalDate plannedDate) { this.plannedDate = plannedDate; }
    public String getMealType() { return mealType; }
    public void setMealType(String mealType) { this.mealType = mealType; }
    public boolean isCompleted() { return completed; }
    public void setCompleted(boolean completed) { this.completed = completed; }
}
