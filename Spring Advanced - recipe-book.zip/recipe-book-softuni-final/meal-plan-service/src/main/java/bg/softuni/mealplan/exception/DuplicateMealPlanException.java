package bg.softuni.mealplan.exception;

public class DuplicateMealPlanException extends RuntimeException {
    public DuplicateMealPlanException(String message) { super(message); }
}
