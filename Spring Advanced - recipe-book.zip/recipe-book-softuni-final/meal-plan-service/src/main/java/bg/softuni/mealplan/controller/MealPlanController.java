package bg.softuni.mealplan.controller;

import bg.softuni.mealplan.dto.MealPlanRequest;
import bg.softuni.mealplan.dto.MealPlanResponse;
import bg.softuni.mealplan.service.MealPlanService;
import jakarta.validation.Valid;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.UUID;

@RestController
@RequestMapping("/api/meal-plans")
public class MealPlanController {
    private final MealPlanService service;
    public MealPlanController(MealPlanService service) { this.service = service; }

    @GetMapping("/user/{userId}") public List<MealPlanResponse> findByUser(@PathVariable UUID userId) { return service.findByUser(userId); }
    @PostMapping @ResponseStatus(HttpStatus.CREATED) public MealPlanResponse create(@Valid @RequestBody MealPlanRequest request) { return service.create(request); }
    @PutMapping("/{id}/complete") public MealPlanResponse complete(@PathVariable UUID id, @RequestParam UUID userId) { return service.complete(id, userId); }
    @DeleteMapping("/{id}") @ResponseStatus(HttpStatus.NO_CONTENT) public void delete(@PathVariable UUID id, @RequestParam UUID userId) { service.delete(id, userId); }
}
