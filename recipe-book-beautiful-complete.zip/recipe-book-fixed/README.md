# Recipe Book

Spring Fundamentals individual project - Recipe Book application.

## Tech stack
- Java 17+
- Spring Boot 3.4.0
- Maven
- Spring MVC + Thymeleaf
- Spring Data JPA
- H2 by default, MySQL configuration included in `application.properties`
- Session-based authentication with `CurrentUser`
- BCrypt password hashing

## Demo login
The application seeds demo data on first start.

- Username: `demo`
- Password: `demo123`
- Role: `ADMIN`

## Main entities
- `User`
- `Recipe`
- `Category`
- `Favorite`

Each entity has exactly one JPA repository and at least one service participating in the application logic.

## Features
- Register and login
- Session-based access control
- USER and ADMIN roles
- Full CRUD for recipes
- Add/remove favorite recipes
- Admin dashboard
- Category creation by admin
- Server-side validation on forms
- Custom business exceptions
- UUID primary keys
- Beautiful Thymeleaf UI with real food photos

## Pages
- Home
- Register
- Login
- All recipes
- Recipe details
- Create recipe
- Edit recipe
- My recipes
- Favorites
- Admin dashboard

## Run
```bash
mvn spring-boot:run
```

Open:

```text
http://localhost:8080
```

## Git commit examples
Use at least 10 commits across 3 different days, for example:

```text
chore: initialize spring boot project
feat: add domain entities and repositories
feat: implement session authentication
feat: add recipe crud functionality
feat: add favorite recipes functionality
feat: create admin dashboard
feat: add thymeleaf views
fix: improve validation messages
refactor: clean service logic
docs: update readme documentation
```
